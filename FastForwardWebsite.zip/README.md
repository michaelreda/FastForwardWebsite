FastForwardWebsite

michael:
- loader (percentage wraper div)
- more about us slider (testimonials section)
